use eframe::egui;

use crate::{
    component::{AnimationClip, AnimationState, Animator, Component},
    editor::EditorApp,
};


pub fn show(app: &mut EditorApp, ui: &mut egui::Ui) {
    egui::ScrollArea::vertical()
        .id_source("animator_root_scroll")
        .auto_shrink([false, false])
        .show(ui, |ui| {
            let Some(entity_id) = app.selected_entity_id.clone() else {
                show_empty_state(ui, "Selecione uma entidade com Animator para abrir esta aba.");
                return;
            };

            let Some(entity) = app.scene.find_entity(&entity_id).cloned() else {
                show_empty_state(ui, "Entidade selecionada não foi encontrada.");
                return;
            };

            let Some(animator_index) = entity
                .components
                .iter()
                .position(|component| matches!(component, Component::Animator(_)))
            else {
                show_empty_state(ui, "A entidade atual não possui componente Animator.");
                return;
            };

            let animator_snapshot = match entity.components.get(animator_index) {
                Some(Component::Animator(animator)) => animator.clone(),
                _ => {
                    show_empty_state(ui, "Não foi possível ler o Animator da entidade.");
                    return;
                }
            };

            let state_names = sorted_state_names(&animator_snapshot);
            ensure_node_layout(app, &state_names);

            if state_names.is_empty() {
                draw_header(ui, &entity.name, &animator_snapshot, "<nenhum>", "<nenhum>", app.animator_detached);
                ui.add_space(6.0);
                draw_help_bar(ui);
                ui.add_space(8.0);
                draw_empty_animator_setup(app, ui, &entity_id, animator_index);
                return;
            }

            if app.animator_selected_state.trim().is_empty()
                || !state_names.iter().any(|name| name == &app.animator_selected_state)
            {
                app.animator_selected_state = preferred_state_name(&animator_snapshot, &state_names);
            }

            let selected_state_name = app.animator_selected_state.clone();
            let selected_state = animator_snapshot
                .states
                .get(&selected_state_name)
                .cloned()
                .unwrap_or_else(|| AnimationState {
                    clip: selected_state_name.clone(),
                    ..AnimationState::default()
                });
            let selected_clip_name = if selected_state.clip.trim().is_empty() {
                selected_state_name.clone()
            } else {
                selected_state.clip.clone()
            };
            let selected_clip = animator_snapshot
                .clips
                .get(&selected_clip_name)
                .cloned()
                .unwrap_or_default();

            draw_header(
                ui,
                &entity.name,
                &animator_snapshot,
                &selected_state_name,
                &selected_clip_name,
                app.animator_detached,
            );
            ui.add_space(6.0);
            draw_help_bar(ui);
            ui.add_space(8.0);

            let compact_layout = ui.available_width() < 980.0;
            if compact_layout {
                draw_state_sidebar(app, ui, &entity_id, animator_index, &animator_snapshot, &state_names);
                ui.add_space(8.0);
                draw_simple_workspace(
                    app,
                    ui,
                    &entity_id,
                    animator_index,
                    &animator_snapshot,
                    &state_names,
                    &selected_state_name,
                    &selected_state,
                    &selected_clip_name,
                    &selected_clip,
                );
            } else {
                ui.columns(2, |columns| {
                    draw_state_sidebar(app, &mut columns[0], &entity_id, animator_index, &animator_snapshot, &state_names);
                    draw_simple_workspace(
                        app,
                        &mut columns[1],
                        &entity_id,
                        animator_index,
                        &animator_snapshot,
                        &state_names,
                        &selected_state_name,
                        &selected_state,
                        &selected_clip_name,
                        &selected_clip,
                    );
                });
            }

        });
}

fn preferred_state_name(animator: &Animator, state_names: &[String]) -> String {
    if !animator.current_state.trim().is_empty() {
        return animator.current_state.clone();
    }
    if !animator.default_state.trim().is_empty() {
        return animator.default_state.clone();
    }
    state_names.first().cloned().unwrap_or_default()
}

fn draw_header(
    ui: &mut egui::Ui,
    entity_name: &str,
    _animator: &Animator,
    selected_state_name: &str,
    selected_clip_name: &str,
    detached: bool,
) {
    egui::Frame::none()
        .fill(egui::Color32::from_rgb(21, 28, 38))
        .rounding(6.0)
        .inner_margin(egui::Margin::same(10.0))
        .show(ui, |ui| {
            ui.horizontal_wrapped(|ui| {
                ui.label(egui::RichText::new("🎞 Animator").strong().size(15.0));
                ui.separator();
                ui.label(format!("Entidade: {}", entity_name));
                ui.separator();
                ui.label(format!("Estado: {}", selected_state_name));
                ui.separator();
                ui.label(format!("Clip: {}", selected_clip_name));
                ui.separator();
                ui.label("Modo: Simples");
                ui.separator();
                ui.label(if detached { "Janela destacada" } else { "Na aba inferior" });
            });
        });
}

fn draw_help_bar(ui: &mut egui::Ui) {
    egui::Frame::none()
        .fill(egui::Color32::from_rgb(18, 24, 32))
        .rounding(6.0)
        .inner_margin(egui::Margin::same(8.0))
        .show(ui, |ui| {
            ui.horizontal_wrapped(|ui| {
                ui.label(egui::RichText::new("Modo simples").strong());
                ui.separator();
                ui.label("1. Crie um estado com o nome que quiser.");
                ui.separator();
                ui.label("2. Arraste sprites para 'Solte frames aqui'.");
                ui.separator();
                ui.label("3. Ajuste FPS, Loop e Próximo estado.");
                ui.separator();
                ui.label("4. Use 'Próximo estado' para fazer a transição de forma fácil.");
            });
        });
}

fn draw_state_sidebar(
    app: &mut EditorApp,
    ui: &mut egui::Ui,
    entity_id: &str,
    animator_index: usize,
    animator: &Animator,
    state_names: &[String],
) {
    egui::Frame::none()
        .fill(egui::Color32::from_rgb(18, 24, 32))
        .rounding(6.0)
        .inner_margin(egui::Margin::same(10.0))
        .show(ui, |ui| {
            ui.set_min_width(210.0);
            ui.horizontal(|ui| {
                ui.label(egui::RichText::new("Estados").strong());
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    if ui.small_button("+ Estado").clicked() {
                        let mut new_name = unique_state_name(animator, "estado");
                        update_animator(app, entity_id, animator_index, |animator| {
                            animator.states.insert(
                                new_name.clone(),
                                AnimationState {
                                    clip: new_name.clone(),
                                    looped: true,
                                    interruptible: true,
                                    next_state: String::new(),
                                },
                            );
                            animator.clips.entry(new_name.clone()).or_insert_with(AnimationClip::default);
                            animator.current_state = new_name.clone();
                            animator.state_mode = true;
                        });
                        let count = state_names.len().max(1) as f32;
                        let y = (0.18 + count * 0.12).min(0.82);
                        app.animator_node_positions.insert(new_name.clone(), [0.40, y]);
                        app.animator_selected_state = std::mem::take(&mut new_name);
                    }
                });
            });
            ui.add_space(6.0);

            egui::ScrollArea::vertical()
                .id_source("animator_state_sidebar")
                .max_height(260.0)
                .show(ui, |ui| {
                    for state_name in state_names {
                        let selected = app.animator_selected_state == *state_name;
                        let response = ui.selectable_label(selected, state_name);
                        if response.clicked() {
                            app.animator_selected_state = state_name.clone();
                        }
                        if response.double_clicked() {
                            let target = state_name.clone();
                            update_animator(app, entity_id, animator_index, move |animator| {
                                animator.current_state = target.clone();
                                if let Some(state) = animator.states.get(&target) {
                                    animator.current = state.clip.clone();
                                    animator.looped = state.looped;
                                }
                            });
                        }

                        let source_name = state_name.clone();
                        response.context_menu(|ui| {
                            ui.label(format!("Estado: {}", source_name));
                            ui.separator();
                            if ui.button("Limpar ligação → saída").clicked() {
                                let source = source_name.clone();
                                update_animator(app, entity_id, animator_index, move |animator| {
                                    if let Some(state) = animator.states.get_mut(&source) {
                                        state.next_state.clear();
                                    }
                                });
                                ui.close_menu();
                            }
                            ui.separator();
                            ui.label("Ligar com:");
                            for target_name in state_names {
                                if target_name != &source_name
                                    && ui.button(format!("→ {}", target_name)).clicked()
                                {
                                    let source = source_name.clone();
                                    let target = target_name.clone();
                                    update_animator(app, entity_id, animator_index, move |animator| {
                                        if let Some(state) = animator.states.get_mut(&source) {
                                            state.next_state = target.clone();
                                        }
                                    });
                                    ui.close_menu();
                                }
                            }
                        });
                    }
                });

            ui.separator();
            ui.label(egui::RichText::new("Ferramentas rápidas").small().strong());
            if ui.small_button("Sincronizar estados pelos clips").clicked() {
                update_animator(app, entity_id, animator_index, |animator| {
                    let mut clip_names: Vec<String> = animator.clips.keys().cloned().collect();
                    clip_names.sort();
                    for clip_name in clip_names {
                        animator.states.entry(clip_name.clone()).or_insert_with(|| AnimationState {
                            clip: clip_name.clone(),
                            looped: clip_name != "attack",
                            interruptible: clip_name != "attack",
                            next_state: if clip_name == "attack" { "idle".to_string() } else { String::new() },
                        });
                    }
                    animator.state_mode = true;
                });
                ensure_node_layout(app, &sorted_state_names(animator));
            }

            ui.horizontal_wrapped(|ui| {
                ui.label("Zoom:");
                ui.add(egui::Slider::new(&mut app.animator_graph_zoom, 0.55..=2.4).clamp_to_range(true));
            });

            if ui.small_button("Reorganizar nós").clicked() {
                app.animator_node_positions.clear();
                ensure_node_layout(app, state_names);
            }
            if ui.small_button("Abrir em janela").clicked() {
                app.animator_detached = true;
            }
            if ui.small_button("Ativar state mode").clicked() {
                update_animator(app, entity_id, animator_index, |animator| {
                    animator.state_mode = true;
                });
            }

            ui.add_space(6.0);
            ui.label(
                egui::RichText::new(
                    "Dica: arraste a bolinha amarela da direita até outro nó ou até a Saída.",
                )
                .small()
                .weak(),
            );
        });
}


fn draw_empty_animator_setup(
    app: &mut EditorApp,
    ui: &mut egui::Ui,
    entity_id: &str,
    animator_index: usize,
) {
    egui::Frame::none()
        .fill(egui::Color32::from_rgb(16, 21, 30))
        .rounding(6.0)
        .inner_margin(egui::Margin::same(14.0))
        .show(ui, |ui| {
            ui.label(egui::RichText::new("Nenhum estado criado ainda").strong());
            ui.add_space(6.0);
            ui.label("Clique no botão abaixo para criar seu primeiro estado vazio. Depois arraste os sprites para a área de frames e ajuste FPS.");
            ui.add_space(10.0);
            if ui.button("+ Criar primeiro estado").clicked() {
                let new_name = "walk".to_string();
                let selected_name = new_name.clone();
                update_animator(app, entity_id, animator_index, move |animator| {
                    animator.states.insert(
                        new_name.clone(),
                        AnimationState {
                            clip: new_name.clone(),
                            looped: true,
                            interruptible: true,
                            next_state: String::new(),
                        },
                    );
                    animator.clips.entry(new_name.clone()).or_insert_with(AnimationClip::default);
                    animator.current_state = new_name.clone();
                    animator.default_state = new_name.clone();
                    animator.state_mode = true;
                });
                app.animator_selected_state = selected_name;
            }
        });
}

fn draw_simple_workspace(
    app: &mut EditorApp,
    ui: &mut egui::Ui,
    entity_id: &str,
    animator_index: usize,
    animator: &Animator,
    state_names: &[String],
    selected_name: &str,
    selected_state: &AnimationState,
    selected_clip_name: &str,
    selected_clip: &AnimationClip,
) {
    egui::Frame::none()
        .fill(egui::Color32::from_rgb(16, 21, 30))
        .rounding(6.0)
        .inner_margin(egui::Margin::same(10.0))
        .show(ui, |ui| {
            ui.label(egui::RichText::new(format!("Editar estado: {}", selected_name)).strong());
            ui.add_space(8.0);

            let compact = ui.available_width() < 720.0;
            if compact {
                draw_clip_drop_and_frames(
                    app,
                    ui,
                    entity_id,
                    animator_index,
                    animator,
                    state_names,
                    selected_name,
                    selected_state,
                    selected_clip_name,
                    selected_clip,
                );
                ui.add_space(10.0);
                draw_preview_and_settings(
                    app,
                    ui,
                    entity_id,
                    animator_index,
                    animator,
                    state_names,
                    selected_name,
                    selected_state,
                    selected_clip_name,
                    selected_clip,
                );
            } else {
                ui.columns(2, |columns| {
                    draw_clip_drop_and_frames(
                        app,
                        &mut columns[0],
                        entity_id,
                        animator_index,
                        animator,
                        state_names,
                        selected_name,
                        selected_state,
                        selected_clip_name,
                        selected_clip,
                    );
                    draw_preview_and_settings(
                        app,
                        &mut columns[1],
                        entity_id,
                        animator_index,
                        animator,
                        state_names,
                        selected_name,
                        selected_state,
                        selected_clip_name,
                        selected_clip,
                    );
                });
            }
        });
}

fn draw_clip_drop_and_frames(
    app: &mut EditorApp,
    ui: &mut egui::Ui,
    entity_id: &str,
    animator_index: usize,
    animator: &Animator,
    _state_names: &[String],
    selected_name: &str,
    selected_state: &AnimationState,
    selected_clip_name: &str,
    selected_clip: &AnimationClip,
) {
    let mut clip_name = if selected_state.clip.trim().is_empty() {
        selected_name.to_string()
    } else {
        selected_state.clip.clone()
    };

    egui::Frame::group(ui.style())
        .inner_margin(egui::Margin::same(10.0))
        .show(ui, |ui| {
            ui.horizontal_wrapped(|ui| {
                ui.label(egui::RichText::new("Frames do estado").strong());
                ui.separator();
                ui.monospace(selected_name);
                ui.separator();
                ui.label(format!("Clip: {}", selected_clip_name));
            });
            ui.add_space(6.0);

            ui.horizontal_wrapped(|ui| {
                ui.label("Clip usado:");
                let clip_names = sorted_clip_names(animator);
                egui::ComboBox::from_id_source("simple_workspace_clip")
                    .selected_text(if clip_name.is_empty() { "<vazio>" } else { clip_name.as_str() })
                    .show_ui(ui, |ui| {
                        for clip in &clip_names {
                            ui.selectable_value(&mut clip_name, clip.clone(), clip);
                        }
                    });
                if ui.button("Salvar clip no estado").clicked() {
                    let target = selected_name.to_string();
                    let clip = clip_name.clone();
                    update_animator(app, entity_id, animator_index, move |animator| {
                        animator.clips.entry(clip.clone()).or_insert_with(AnimationClip::default);
                        animator.states.entry(target.clone()).or_default().clip = clip.clone();
                    });
                }
            });

            ui.add_space(8.0);
            draw_frame_drop_zone(app, ui, entity_id, animator_index, &clip_name);
            ui.add_space(8.0);
            draw_frames_list(app, ui, entity_id, animator_index, &clip_name, selected_clip);
        });
}

fn draw_preview_and_settings(
    app: &mut EditorApp,
    ui: &mut egui::Ui,
    entity_id: &str,
    animator_index: usize,
    animator: &Animator,
    state_names: &[String],
    selected_name: &str,
    selected_state: &AnimationState,
    selected_clip_name: &str,
    selected_clip: &AnimationClip,
) {
    egui::Frame::group(ui.style())
        .inner_margin(egui::Margin::same(10.0))
        .show(ui, |ui| {
            ui.label(egui::RichText::new("Preview e ajustes").strong());
            ui.add_space(8.0);
            draw_clip_preview(app, ui, selected_clip_name, selected_clip);
            ui.add_space(10.0);
            draw_simple_settings(app, ui, entity_id, animator_index, animator, state_names, selected_name, selected_state, selected_clip_name, selected_clip);
        });
}

fn draw_frame_drop_zone(
    app: &mut EditorApp,
    ui: &mut egui::Ui,
    entity_id: &str,
    animator_index: usize,
    clip_name: &str,
) {
    let desired_h = 96.0;
    let (rect, response) = ui.allocate_exact_size(
        egui::vec2(ui.available_width().max(220.0), desired_h),
        egui::Sense::hover(),
    );
    let painter = ui.painter_at(rect);

    let hovering_internal = app
        .dragging_asset_path
        .as_ref()
        .map(|p| is_image_asset_path(p) && response.hovered())
        .unwrap_or(false);
    let dropped_files = ui.ctx().input(|i| i.raw.dropped_files.clone());
    let hovering_external = !dropped_files.is_empty() && response.hovered();
    let active = hovering_internal || hovering_external;
    let stroke = if active {
        egui::Stroke::new(2.0, egui::Color32::from_rgb(120, 200, 255))
    } else {
        egui::Stroke::new(1.0, egui::Color32::from_gray(75))
    };
    painter.rect_filled(rect, 8.0, egui::Color32::from_rgb(21, 28, 38));
    painter.rect_stroke(rect, 8.0, stroke);
    painter.text(
        rect.center_top() + egui::vec2(0.0, 22.0),
        egui::Align2::CENTER_CENTER,
        "Solte frames aqui",
        egui::FontId::proportional(16.0),
        egui::Color32::WHITE,
    );
    painter.text(
        rect.center_bottom() - egui::vec2(0.0, 22.0),
        egui::Align2::CENTER_CENTER,
        "Arraste imagens do Assets ou do sistema",
        egui::FontId::proportional(12.0),
        egui::Color32::from_rgb(170, 185, 205),
    );

    ui.add_space(4.0);
    ui.horizontal_wrapped(|ui| {
        if ui.button("+ asset selecionado").clicked() {
            if let Some(path) = app.selected_asset.clone() {
                if is_image_asset_path(&path) {
                    let rel = relative_to_project_or_full(&app.project_root, &path);
                    append_frames_to_clip(app, entity_id, animator_index, clip_name, vec![rel]);
                }
            }
        }
        if ui.button("Limpar frames").clicked() {
            let clip = clip_name.to_string();
            update_animator(app, entity_id, animator_index, move |animator| {
                animator.clips.entry(clip.clone()).or_default().frames.clear();
            });
        }
    });

    if hovering_internal && ui.ctx().input(|i| i.pointer.any_released()) {
        if let Some(path) = app.dragging_asset_path.clone() {
            let rel = relative_to_project_or_full(&app.project_root, &path);
            append_frames_to_clip(app, entity_id, animator_index, clip_name, vec![rel]);
        }
    }

    if response.hovered() && !dropped_files.is_empty() {
        let mut to_add = Vec::new();
        for file in dropped_files {
            if let Some(path) = file.path {
                if is_image_asset_path(&path) {
                    to_add.push(relative_to_project_or_full(&app.project_root, &path));
                }
            }
        }
        if !to_add.is_empty() {
            append_frames_to_clip(app, entity_id, animator_index, clip_name, to_add);
        }
    }
}

fn draw_frames_list(
    app: &mut EditorApp,
    ui: &mut egui::Ui,
    entity_id: &str,
    animator_index: usize,
    clip_name: &str,
    clip: &AnimationClip,
) {
    ui.label(egui::RichText::new("Lista de frames").strong());
    ui.add_space(4.0);
    if clip.frames.is_empty() {
        ui.label(egui::RichText::new("Nenhum frame ainda. Arraste sprites para a caixa acima.").small().weak());
        return;
    }

    egui::ScrollArea::vertical().max_height(320.0).show(ui, |ui| {
        for (index, frame) in clip.frames.iter().enumerate() {
            egui::Frame::group(ui.style()).show(ui, |ui| {
                ui.horizontal_wrapped(|ui| {
                    if let Some(texture) = app.load_texture_from_relative_path(ui.ctx(), frame) {
                        ui.image((texture.id(), egui::vec2(40.0, 40.0)));
                    }
                    ui.vertical(|ui| {
                        ui.label(egui::RichText::new(format!("Frame {}", index + 1)).strong().small());
                        ui.label(egui::RichText::new(frame).small().weak());
                    });
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        if ui.small_button("🗑").clicked() {
                            remove_frame(app, entity_id, animator_index, clip_name, index);
                        }
                        if index + 1 < clip.frames.len() && ui.small_button("↓").clicked() {
                            move_frame(app, entity_id, animator_index, clip_name, index, index + 1);
                        }
                        if index > 0 && ui.small_button("↑").clicked() {
                            move_frame(app, entity_id, animator_index, clip_name, index, index - 1);
                        }
                    });
                });
            });
            ui.add_space(4.0);
        }
    });
}

fn draw_clip_preview(
    app: &mut EditorApp,
    ui: &mut egui::Ui,
    clip_name: &str,
    clip: &AnimationClip,
) {
    ui.label(egui::RichText::new("Preview").strong());
    ui.add_space(6.0);
    let preview_h = if ui.available_width() < 340.0 { 180.0 } else { 240.0 };
    let (rect, _) = ui.allocate_exact_size(
        egui::vec2(ui.available_width().max(220.0), preview_h),
        egui::Sense::hover(),
    );
    let painter = ui.painter_at(rect);
    painter.rect_filled(rect, 8.0, egui::Color32::from_rgb(12, 17, 25));

    if clip.frames.is_empty() {
        painter.text(
            rect.center(),
            egui::Align2::CENTER_CENTER,
            "Adicione frames para ver o preview",
            egui::FontId::proportional(15.0),
            egui::Color32::from_rgb(170, 185, 205),
        );
        return;
    }

    let fps = clip.fps.max(1.0);
    let time = ui.input(|i| i.time) as f32;
    let frame_index = ((time * fps) as usize) % clip.frames.len();
    let frame_path = &clip.frames[frame_index];
    if let Some(texture) = app.load_texture_from_relative_path(ui.ctx(), frame_path) {
        let size = texture.size_vec2();
        let scale = (rect.width() / size.x).min(rect.height() / size.y).min(1.0);
        let draw_size = size * scale * 0.9;
        let image_rect = egui::Rect::from_center_size(rect.center(), draw_size);
        painter.image(
            texture.id(),
            image_rect,
            egui::Rect::from_min_max(egui::Pos2::ZERO, egui::pos2(1.0, 1.0)),
            egui::Color32::WHITE,
        );
        painter.text(
            rect.left_top() + egui::vec2(10.0, 10.0),
            egui::Align2::LEFT_TOP,
            format!("{}  •  frame {}/{}", clip_name, frame_index + 1, clip.frames.len()),
            egui::FontId::proportional(12.0),
            egui::Color32::from_rgb(215, 225, 240),
        );
        ui.ctx().request_repaint();
    } else {
        painter.text(
            rect.center(),
            egui::Align2::CENTER_CENTER,
            format!("Não foi possível abrir
{}", frame_path),
            egui::FontId::proportional(14.0),
            egui::Color32::from_rgb(214, 102, 102),
        );
    }
}

fn draw_simple_settings(
    app: &mut EditorApp,
    ui: &mut egui::Ui,
    entity_id: &str,
    animator_index: usize,
    animator: &Animator,
    state_names: &[String],
    selected_name: &str,
    selected_state: &AnimationState,
    selected_clip_name: &str,
    clip: &AnimationClip,
) {
    let mut fps = clip.fps;
    let mut looped = selected_state.looped;
    let mut interruptible = selected_state.interruptible;
    let mut next_state = selected_state.next_state.clone();
    let mut default_state = animator.default_state.clone();
    let mut threshold = animator.locomotion_threshold;

    egui::Grid::new("simple_settings_grid").num_columns(2).spacing([10.0, 8.0]).show(ui, |ui| {
        ui.label("FPS:");
        ui.add(egui::DragValue::new(&mut fps).speed(0.25).range(1.0..=60.0));
        ui.end_row();

        ui.label("Loop:");
        ui.checkbox(&mut looped, "Repetir animação");
        ui.end_row();

        ui.label("Interruptível:");
        ui.checkbox(&mut interruptible, "Pode trocar no meio");
        ui.end_row();

        ui.label("Próximo estado:");
        egui::ComboBox::from_id_source("simple_next_state")
            .selected_text(if next_state.is_empty() { "<nenhum>" } else { next_state.as_str() })
            .show_ui(ui, |ui| {
                ui.selectable_value(&mut next_state, String::new(), "<nenhum>");
                for name in state_names {
                    if name != selected_name {
                        ui.selectable_value(&mut next_state, name.clone(), name);
                    }
                }
            });
        ui.end_row();

        ui.label("Estado padrão:");
        egui::ComboBox::from_id_source("simple_default_state")
            .selected_text(if default_state.is_empty() { "<nenhum>" } else { default_state.as_str() })
            .show_ui(ui, |ui| {
                for name in state_names {
                    ui.selectable_value(&mut default_state, name.clone(), name);
                }
            });
        ui.end_row();

        ui.label("Threshold movimento:");
        ui.add(egui::DragValue::new(&mut threshold).speed(0.25).range(0.0..=999.0));
        ui.end_row();
    });

    ui.add_space(8.0);
    if ui.button("Salvar ajustes").clicked() {
        let state_name = selected_name.to_string();
        let clip_name = selected_clip_name.to_string();
        update_animator(app, entity_id, animator_index, move |animator| {
            animator.state_mode = true;
            animator.default_state = default_state.clone();
            animator.locomotion_threshold = threshold;
            animator.clips.entry(clip_name.clone()).or_default().fps = fps;
            animator.states.insert(
                state_name.clone(),
                AnimationState {
                    clip: clip_name.clone(),
                    looped,
                    interruptible,
                    next_state: next_state.clone(),
                },
            );
        });
    }
}

fn append_frames_to_clip(
    app: &mut EditorApp,
    entity_id: &str,
    animator_index: usize,
    clip_name: &str,
    frames: Vec<String>,
) {
    if frames.is_empty() {
        return;
    }
    let clip = clip_name.to_string();
    update_animator(app, entity_id, animator_index, move |animator| {
        let entry = animator.clips.entry(clip.clone()).or_default();
        for frame in &frames {
            if !entry.frames.iter().any(|existing| existing == frame) {
                entry.frames.push(frame.clone());
            }
        }
    });
}

fn move_frame(
    app: &mut EditorApp,
    entity_id: &str,
    animator_index: usize,
    clip_name: &str,
    from: usize,
    to: usize,
) {
    let clip = clip_name.to_string();
    update_animator(app, entity_id, animator_index, move |animator| {
        let frames = &mut animator.clips.entry(clip.clone()).or_default().frames;
        if from < frames.len() && to < frames.len() {
            let frame = frames.remove(from);
            frames.insert(to, frame);
        }
    });
}

fn remove_frame(
    app: &mut EditorApp,
    entity_id: &str,
    animator_index: usize,
    clip_name: &str,
    index: usize,
) {
    let clip = clip_name.to_string();
    update_animator(app, entity_id, animator_index, move |animator| {
        let frames = &mut animator.clips.entry(clip.clone()).or_default().frames;
        if index < frames.len() {
            frames.remove(index);
        }
    });
}

fn is_image_asset_path(path: &std::path::Path) -> bool {
    matches!(
        path.extension().and_then(|e| e.to_str()).map(|e| e.to_ascii_lowercase()),
        Some(ext) if matches!(ext.as_str(), "png" | "jpg" | "jpeg" | "webp")
    )
}

fn relative_to_project_or_full(project_root: &std::path::Path, path: &std::path::Path) -> String {
    if let Ok(relative) = path.strip_prefix(project_root) {
        return relative.to_string_lossy().replace('\\', "/");
    }
    path.to_string_lossy().replace('\\', "/")
}


fn show_empty_state(ui: &mut egui::Ui, text: &str) {
    ui.vertical_centered(|ui| {
        ui.add_space(24.0);
        ui.label(egui::RichText::new(text).strong());
    });
}

fn sorted_state_names(animator: &Animator) -> Vec<String> {
    let mut names: Vec<String> = animator.states.keys().cloned().collect();
    names.sort();
    names
}

fn sorted_clip_names(animator: &Animator) -> Vec<String> {
    let mut names: Vec<String> = animator.clips.keys().cloned().collect();
    names.sort();
    names
}

fn unique_state_name(animator: &Animator, base: &str) -> String {
    if !animator.states.contains_key(base) {
        return base.to_string();
    }
    let mut index = 1usize;
    loop {
        let candidate = format!("{}_{}", base, index);
        if !animator.states.contains_key(&candidate) {
            return candidate;
        }
        index += 1;
    }
}

fn ensure_node_layout(app: &mut EditorApp, state_names: &[String]) {
    for (index, state_name) in state_names.iter().enumerate() {
        app.animator_node_positions.entry(state_name.clone()).or_insert_with(|| {
            let row = index as f32;
            [0.25 + ((index % 2) as f32) * 0.28, (0.18 + row * 0.12).min(0.82)]
        });
    }
    app.animator_node_positions.retain(|name, _| state_names.iter().any(|state| state == name));
}

fn update_animator<F>(app: &mut EditorApp, entity_id: &str, animator_index: usize, mut update: F)
where
    F: FnMut(&mut Animator),
{
    if let Some(entity) = app.scene.find_entity_mut(entity_id) {
        if let Some(Component::Animator(animator)) = entity.components.get_mut(animator_index) {
            update(animator);
        }
    }
}

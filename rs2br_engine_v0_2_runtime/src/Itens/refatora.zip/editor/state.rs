// Estado e tipos principais do editor
use serde::{Deserialize, Serialize};
use std::{collections::HashMap, path::{Path, PathBuf}};
use crate::engine::{assets::AssetManager, component::{Component, Sprite}, entity::Entity, scene::Scene};
use crate::runtime::RuntimeState;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum EditorPlayState {
    Edit,
    Playing,
    Paused,
}

#[derive(Debug, Clone)]
pub enum DeleteTarget {
    Entities { ids: Vec<String>, label: String },
    Asset { path: PathBuf, label: String },
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EditorLayout {
    pub hierarchy_width: f32,
    pub inspector_width: f32,
    pub asset_height: f32,
}

impl Default for EditorLayout {
    fn default() -> Self {
        Self {
            hierarchy_width: 240.0,
            inspector_width: 300.0,
            asset_height: 220.0,
        }
    }
}

pub struct EditorApp {
    pub scene: Scene,
    pub selected_entity_id: Option<String>,
    pub selected_entity_ids: Vec<String>,
    pub selected_asset: Option<PathBuf>,
    pub assets: AssetManager,
    pub project_root: PathBuf,
    pub status_msg: String,
    pub scene_zoom: f32,
    pub scene_pan: eframe::egui::Vec2,
    pub show_entity_names: bool,
    pub show_colliders: bool,
    pub snap_to_grid: bool,
    pub asset_search: String,
    pub sprite_textures: HashMap<String, eframe::egui::TextureHandle>,
    pub dragging_asset_path: Option<PathBuf>,
    pub active_drag_entity_id: Option<String>,
    pub delete_confirmation: Option<DeleteTarget>,
    pub rename_asset_dialog: Option<(PathBuf, String)>,
    pub rename_entity_dialog: Option<(String, String)>,
    pub layout: EditorLayout,
    pub selection_box_start: Option<eframe::egui::Pos2>,
    pub selection_box_current: Option<eframe::egui::Pos2>,
    pub undo_stack: Vec<Scene>,
    pub redo_stack: Vec<Scene>,
    pub play_state: EditorPlayState,
    pub runtime: RuntimeState,
    pub new_script_dialog: Option<(PathBuf, String)>,
    pub new_folder_dialog: Option<(PathBuf, String)>,
    pub new_entity_dialog: Option<String>,
}

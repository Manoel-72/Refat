// Funções e structs de scripts do runtime
// (mover aqui o que for parsing/execução de scripts)

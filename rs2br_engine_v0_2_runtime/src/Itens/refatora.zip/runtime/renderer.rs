// Funções de desenho do runtime
// (mover aqui o que for desenho do runtime)

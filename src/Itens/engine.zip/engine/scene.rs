// ============================================================
//  engine/scene.rs
//  Uma cena é a "tela do jogo" — contém todas as entidades.
//  Pode ser salva/carregada como JSON.
// ============================================================

use serde::{Serialize, Deserialize};
use super::entity::Entity;
use super::component::{Component, Camera2D};

/// Representa uma cena 2D completa
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Scene {
    pub name: String,
    /// Todas as entidades de nível raiz (podem ter filhos)
    pub entities: Vec<Entity>,
    /// Cor de fundo da cena (R, G, B)
    pub background_color: [f32; 3],
}

impl Scene {
    /// Cria uma cena nova com entidades padrão
    pub fn new(name: impl Into<String>) -> Self {
        // Câmera padrão já presente na cena
        let mut camera = Entity::new("Camera");
        camera.add_component(Component::Camera2D(Camera2D::default()));

        Self {
            name: name.into(),
            entities: vec![camera],
            background_color: [0.15, 0.15, 0.18],
        }
    }

    /// Adiciona uma entidade na raiz da cena
    pub fn add_entity(&mut self, entity: Entity) {
        self.entities.push(entity);
    }

    /// Remove uma entidade pelo ID (busca recursiva)
    pub fn remove_entity_by_id(&mut self, id: &str) {
        self.entities.retain(|e| e.id != id);
        for entity in &mut self.entities {
            remove_child_by_id(&mut entity.children, id);
        }
    }

    /// Serializa a cena para JSON
    pub fn to_json(&self) -> String {
        serde_json::to_string_pretty(self).unwrap_or_default()
    }

    /// Carrega uma cena a partir de JSON
    pub fn from_json(json: &str) -> Option<Self> {
        serde_json::from_str(json).ok()
    }
}

fn remove_child_by_id(children: &mut Vec<Entity>, id: &str) {
    children.retain(|e| e.id != id);
    for child in children.iter_mut() {
        remove_child_by_id(&mut child.children, id);
    }
}

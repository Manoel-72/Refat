// ============================================================
//  engine/entity.rs
//  Entidade: um objeto do mundo do jogo.
//  Cada entidade tem um ID único e uma lista de componentes.
// ============================================================

use uuid::Uuid;
use serde::{Serialize, Deserialize};
use super::component::Component;

/// Uma entidade é simplesmente um ID + nome + lista de componentes.
/// É o "objeto" que você coloca na cena.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Entity {
    /// ID único gerado automaticamente
    pub id: String,
    /// Nome visível na hierarquia
    pub name: String,
    /// Se a entidade está visível na cena
    pub visible: bool,
    /// Entidades filhas (hierarquia pai→filho)
    pub children: Vec<Entity>,
    /// Componentes anexados a esta entidade
    pub components: Vec<Component>,
    /// Origem opcional de um MATR instanciado na cena
    #[serde(default)]
    pub matr_source: Option<String>,
}

impl Entity {
    /// Cria uma nova entidade com nome e ID automático
    pub fn new(name: impl Into<String>) -> Self {
        Self {
            id: Uuid::new_v4().to_string(),
            name: name.into(),
            visible: true,
            children: Vec::new(),
            components: vec![
                // Todo objeto começa com Transform (posição/rotação/escala)
                Component::transform_default(),
            ],
            matr_source: None,
        }
    }

    /// Adiciona um componente à entidade
    pub fn add_component(&mut self, component: Component) {
        self.components.push(component);
    }

    /// Remove componente pelo índice
    pub fn remove_component(&mut self, index: usize) {
        if index < self.components.len() {
            self.components.remove(index);
        }
    }

    /// Serializa a entidade para JSON bonito (útil para MATRs)
    pub fn to_json(&self) -> String {
        serde_json::to_string_pretty(self).unwrap_or_default()
    }

    /// Carrega uma entidade a partir de JSON
    pub fn from_json(json: &str) -> Option<Self> {
        serde_json::from_str(json).ok()
    }

    /// Regenera o ID desta entidade e de todos os filhos.
    /// Útil ao instanciar MATRs sem duplicar UUIDs.
    pub fn regenerate_ids_recursive(&mut self) {
        self.id = Uuid::new_v4().to_string();
        for child in &mut self.children {
            child.regenerate_ids_recursive();
        }
    }

    /// Adiciona uma entidade filha.
    ///
    /// Mantido como parte da API da hierarquia para uso futuro no editor.
    #[allow(dead_code)]
    pub fn add_child(&mut self, child: Entity) {
        self.children.push(child);
    }
}

// ============================================================
//  runtime/mod.rs
//  Fachada do runtime dentro do editor.
//  A lógica pesada foi separada por responsabilidade.
// ============================================================

pub mod camera;
pub mod input;
pub mod renderer;
pub mod script;
pub mod state;
pub mod systems;

pub use state::{RuntimeInput, RuntimeState};

use eframe::egui;

use crate::editor::{EditorApp, EditorPlayState};

pub fn show_viewport(app: &mut EditorApp, ctx: &egui::Context) {
    if app.play_state == EditorPlayState::Edit || !app.runtime.window_open {
        return;
    }

    let viewport_id = egui::ViewportId::from_hash_of("rust2d_runtime_viewport");
    ctx.show_viewport_immediate(
        viewport_id,
        egui::ViewportBuilder::default()
            .with_title("▶ Rust2D Runtime")
            .with_inner_size([960.0, 640.0])
            .with_min_inner_size([480.0, 320.0]),
        |ctx, _class| {
            if ctx.input(|i| i.viewport().close_requested()) {
                app.play_state = EditorPlayState::Edit;
                app.runtime.stop();
                app.runtime.window_open = false;
                app.status_msg = "Runtime fechado".to_string();
                return;
            }
            egui::CentralPanel::default().show(ctx, |ui| {
                ui.horizontal(|ui| {
                    if ui.button("▶ Play").clicked() {
                        app.play_state = EditorPlayState::Playing;
                        app.runtime.window_open = true;
                        app.runtime.start_from_scene(&app.scene);
                        app.status_msg = "▶ Runtime em execução".to_string();
                    }
                    if ui.button("⏸ Pause").clicked() {
                        app.play_state = EditorPlayState::Paused;
                        app.status_msg = "⏸ Runtime pausado".to_string();
                    }
                    if ui.button("⏹ Parar").clicked() {
                        app.play_state = EditorPlayState::Edit;
                        app.runtime.stop();
                        app.runtime.window_open = false;
                        app.status_msg = "⏹ Runtime parado".to_string();
                    }
                    if ui.button("↻ Recarregar Cena").clicked() {
                        app.runtime.start_from_scene(&app.scene);
                        app.status_msg = "↻ Cena recarregada no runtime".to_string();
                    }
                    ui.separator();
                    if ui.button("✖ Fechar runtime").clicked() {
                        app.play_state = EditorPlayState::Edit;
                        app.runtime.stop();
                        app.runtime.window_open = false;
                        app.status_msg = "Runtime fechado".to_string();
                    }
                });
                show(app, ui);
            });
        },
    );
}

pub fn show(app: &mut EditorApp, ui: &mut egui::Ui) {
    let play_state = app.play_state;
    let editor_scene_snapshot = app.scene.clone();
    app.runtime.sync_with_mode(play_state, &editor_scene_snapshot, &app.project_root);
    input::apply_runtime_inputs(app, ui.ctx());

    let Some(runtime_scene) = app.runtime.active_scene.clone() else {
        ui.centered_and_justified(|ui| {
            ui.label("Runtime inativo.");
        });
        return;
    };

    if app.play_state != EditorPlayState::Edit {
        ui.ctx().request_repaint();
    }

    ui.horizontal_wrapped(|ui| {
        ui.heading("▶ Runtime Preview");
        ui.separator();
        ui.label(format!("📌 {}", runtime_scene.name));
        ui.separator();
        ui.label(format!("⏱ {:.2}s", app.runtime.elapsed_time));
        ui.separator();
        ui.label(format!("FPS ~ {:.0}", app.runtime.estimated_fps()));
        ui.separator();
        ui.label(match app.play_state {
            EditorPlayState::Playing => "Status: Executando",
            EditorPlayState::Paused => "Status: Pausado",
            EditorPlayState::Edit => "Status: Edição",
        });
    });

    ui.label("Runtime jogável: carrega a cena atual, renderiza sprites, atualiza física e executa scripts anexados.");
    ui.label("WASD = mover entidade com @player_controller | Setas = mover câmera | Q/E ou scroll = zoom | R = recarregar cena");
    ui.separator();

    renderer::draw_runtime(ui, app, &runtime_scene);
}

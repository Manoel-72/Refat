use std::{collections::HashSet, path::Path};

use crate::engine::{component::Component, entity::Entity};

use super::script;

pub const GROUND_Y: f32 = -260.0;

fn aabb_collision(a: (f32, f32, f32, f32), b: (f32, f32, f32, f32)) -> bool {
    let (ax, ay, aw, ah) = a;
    let (bx, by, bw, bh) = b;
    ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by
}

pub fn update_entities_runtime(
    entities: &mut [Entity],
    delta_time: f32,
    _elapsed_time: f32,
    project_root: &Path,
    started_scripts: &mut HashSet<String>,
    camera_follow_target: &mut Option<(f32, f32)>,
) {
    let mut colliders = Vec::new();
    for entity in entities.iter() {
        let mut t_opt = None;
        let mut c_opt = None;
        for comp in &entity.components {
            match comp {
                Component::Transform(t) => t_opt = Some(t),
                Component::BoxCollider(c) => c_opt = Some(c),
                _ => {}
            }
        }
        if let (Some(t), Some(c)) = (t_opt, c_opt) {
            colliders.push((t.x + c.offset_x, t.y + c.offset_y, c.width, c.height, entity as *const Entity));
        }
    }

    for entity in entities {
        let mut gravity_scale = None;
        let mut is_static = false;
        let mut collider_half_height = 0.0_f32;
        let mut script_move_x = 0.0_f32;
        let mut script_move_y = 0.0_f32;
        let mut script_rotate_speed = 0.0_f32;
        let mut should_follow_camera = false;

        for component in &entity.components {
            match component {
                Component::RigidBody2D(rb) => {
                    gravity_scale = Some(rb.gravity_scale);
                    is_static = rb.is_static;
                }
                Component::BoxCollider(collider) => {
                    collider_half_height = collider.height.max(0.0) * 0.5;
                }
                Component::Script(script_component) => {
                    if let Some(behavior) = script::load_script_behavior(project_root, &script_component.file_path) {
                        let script_key = format!("{}::{}", entity.id, script_component.file_path);
                        if started_scripts.insert(script_key) {
                            if let Some(message) = &behavior.start_message {
                                println!("▶ Script '{}' em '{}': {}", script_component.file_path, entity.name, message);
                            } else {
                                println!("▶ Script '{}' iniciado em '{}'", script_component.file_path, entity.name);
                            }
                        }

                        script_move_x += behavior.move_x;
                        script_move_y += behavior.move_y;
                        script_rotate_speed += behavior.rotate_speed;
                        should_follow_camera |= behavior.camera_follow;
                    }
                }
                _ => {}
            }
        }

        let my_collider_data = entity.components.iter().find_map(|comp| {
            if let Component::BoxCollider(c) = comp {
                Some((c.offset_x, c.offset_y, c.width, c.height))
            } else {
                None
            }
        });
        let entity_ptr = entity as *const Entity;

        if let Some(Component::Transform(t)) = entity.components.get_mut(0) {
            let old_x = t.x;
            let old_y = t.y;

            t.x += script_move_x * delta_time;
            t.y += script_move_y * delta_time;
            t.rotation += script_rotate_speed * delta_time;

            if !is_static {
                if let Some(gravity) = gravity_scale {
                    t.y -= 180.0 * gravity.max(0.0) * delta_time;
                }
            }

            if let Some((off_x, off_y, width, height)) = my_collider_data {
                let my_rect = (
                    t.x + off_x - width * 0.5,
                    t.y + off_y - height * 0.5,
                    width,
                    height,
                );
                for (ox, oy, ow, oh, other_ptr) in &colliders {
                    if std::ptr::eq(entity_ptr, *other_ptr) {
                        continue;
                    }
                    let other_rect = (*ox - *ow * 0.5, *oy - *oh * 0.5, *ow, *oh);
                    if aabb_collision(my_rect, other_rect) {
                        t.x = old_x;
                        t.y = old_y;
                        break;
                    }
                }
            }

            let floor_y = GROUND_Y + collider_half_height.max(16.0);
            if t.y < floor_y {
                t.y = floor_y;
            }

            if should_follow_camera {
                *camera_follow_target = Some((t.x, t.y));
            }
        }

        update_entities_runtime(
            &mut entity.children,
            delta_time,
            _elapsed_time,
            project_root,
            started_scripts,
            camera_follow_target,
        );
    }
}

pub fn apply_player_controller_input(
    entities: &mut [Entity],
    project_root: &Path,
    delta_time: f32,
    input: eframe::egui::Vec2,
) {
    for entity in entities {
        let mut controller_speed = 0.0_f32;

        for component in &entity.components {
            if let Component::Script(script_component) = component {
                if let Some(behavior) = script::load_script_behavior(project_root, &script_component.file_path) {
                    controller_speed = controller_speed.max(behavior.player_controller_speed.abs());
                }
            }
        }

        if controller_speed > 0.0 {
            if let Some(Component::Transform(t)) = entity.components.get_mut(0) {
                t.x += input.x * controller_speed * delta_time;
                t.y += input.y * controller_speed * delta_time;
            }
        }

        apply_player_controller_input(&mut entity.children, project_root, delta_time, input);
    }
}

pub fn count_entities(entities: &[Entity]) -> usize {
    entities.iter().map(|e| 1 + count_entities(&e.children)).sum()
}

pub fn count_scripts(entities: &[Entity]) -> usize {
    let mut count = 0;
    for entity in entities {
        for component in &entity.components {
            if matches!(component, Component::Script(_)) {
                count += 1;
            }
        }
        count += count_scripts(&entity.children);
    }
    count
}
